package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.*;

/** url: http://localhost:8080/api/... **/

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class Controller {

    @Autowired
    private MongoDB accesoABaseDeDatos;

    public Controller() {
        this.accesoABaseDeDatos = new MongoDB();
    }

    @RequestMapping(value = "/datos/productos", method = RequestMethod.POST)
    public ResponseEntity<Object> agregarProductoInalabrico(@RequestBody HashMap producto) {
        accesoABaseDeDatos.ingresarProductoInalambrico(producto);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @RequestMapping(value = "/datos/productos/concable", method = RequestMethod.POST)
    public ResponseEntity<Object> agregarProductoConCable(@RequestBody HashMap producto) {
        accesoABaseDeDatos.ingresarProductosConCables(producto);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @RequestMapping(value = "/datos/productos", method = RequestMethod.GET)
    public ResponseEntity<Object> buscarProductos() {
        HashMap<String,Object> data = accesoABaseDeDatos.obtenerDatosProducto();
        return new ResponseEntity<>(data,HttpStatus.OK);
    }

    @RequestMapping(value = "/datos/productos/{nombre}", method = RequestMethod.GET)
    public ResponseEntity<Object> buscarProducto(@PathVariable String nombre) {
        HashMap<String,Object> data = accesoABaseDeDatos.obtenerProducto(nombre);
        return new ResponseEntity<>(data,HttpStatus.OK);
    }

    //UPDATE

    @RequestMapping(value = "/datos/productos/{nombre}", method = RequestMethod.PATCH)
    public ResponseEntity<Object> modificarProducto(@PathVariable String nombre,@RequestBody HashMap nuevosDatos) {
        String campo = (String) nuevosDatos.get("campo");
        Object valor = nuevosDatos.get("nuevoValor");
        System.out.println("object valor: " + valor);
        accesoABaseDeDatos.actualizarDocumento(nombre,campo,valor,"producto");
        return new ResponseEntity<>(HttpStatus.OK);
    }

    //DELETE

    @RequestMapping(value = "/datos/productos/{nombre}", method = RequestMethod.DELETE)
    public ResponseEntity<Object> borrarProducto(@PathVariable String nombre) {
        accesoABaseDeDatos.eliminarDocumento(nombre,"producto");
        return new ResponseEntity<>(HttpStatus.OK);
    }

}

