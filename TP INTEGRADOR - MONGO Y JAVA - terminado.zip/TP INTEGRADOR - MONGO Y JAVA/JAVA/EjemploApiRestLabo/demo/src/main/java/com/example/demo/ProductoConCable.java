package com.example.demo;

public class ProductoConCable extends Producto implements MetodosProducto {
    private int largoCable;
    private String conector;
    private String velocidadDeRespuesta;

    public ProductoConCable(){
        super();

    }

    public ProductoConCable(String nombre, String descripcion, String categoria, double precioCompra, double precioVenta, int stock, int stockMinimo, String nombreProveedor, int largoCable, String conector, String velocidadDeRespuesta) {
        super(nombre, descripcion, categoria, precioCompra, precioVenta, stock, stockMinimo, nombreProveedor);
        String descripcionNueva = this.generarDescripcion();
        System.out.println(descripcionNueva);
        this.setDescripcion(descripcionNueva);
        this.largoCable = largoCable;
        this.conector = conector;
        this.velocidadDeRespuesta = velocidadDeRespuesta;
    }

    public int getLargoCable() {
        return largoCable;
    }

    public void setLargoCable(int largoCable) {
        this.largoCable = largoCable;
    }

    public String getConector() {
        return conector;
    }

    public void setConector(String conector) {
        this.conector = conector;
    }

    public String getVelocidadDeRespuesta() {
        return velocidadDeRespuesta;
    }

    public void setVelocidadDeRespuesta(String velocidadDeRespuesta) {
        this.velocidadDeRespuesta = velocidadDeRespuesta;
    }

    @Override
    public String generarDescripcion() {
        String descripcion;

        descripcion = "Largo del cable: " + this.largoCable + "\n" + "Conector: " + this.conector + "\n" + "Velocidad de Respuesta: " + this.velocidadDeRespuesta;

        this.setDescripcion(descripcion);
        return descripcion;
    }
}
