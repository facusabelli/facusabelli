package com.example.demo;

public class ProductoInalambrico extends Producto implements MetodosProducto {
    private int frecuencia;
    private int tiempoBateria;

    public ProductoInalambrico(){

    }

    public ProductoInalambrico(String nombre, String descripcion, String categoria, double precioCompra, double precioVenta, int stock, int stockMinimo, String nombreProveedor, int frecuencia, int tiempoBateria) {
        super(nombre, descripcion, categoria, precioCompra, precioVenta, stock, stockMinimo, nombreProveedor);
        String descripcionNueva = this.generarDescripcion();
        this.setDescripcion(descripcionNueva);
        this.frecuencia = frecuencia;
        this.tiempoBateria = tiempoBateria;
    }

    public int getFrecuencia() {
        return frecuencia;
    }

    public void setFrecuencia(int frecuencia) {
        this.frecuencia = frecuencia;
    }

    public int getTiempoBateria() {
        return tiempoBateria;
    }

    public void setTiempoBateria(int tiempoBateria) {
        this.tiempoBateria = tiempoBateria;
    }

    @Override
    public String generarDescripcion() {
        String descripcion;

        descripcion = "Frecuencia: " + this.frecuencia + "\n" + "Tiempo de bateria: " + this.tiempoBateria;

        this.setDescripcion(descripcion);

        return descripcion;
    }
}
