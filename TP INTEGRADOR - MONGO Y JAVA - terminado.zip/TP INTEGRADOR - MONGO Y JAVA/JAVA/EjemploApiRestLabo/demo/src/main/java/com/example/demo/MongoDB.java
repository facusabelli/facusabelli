package com.example.demo;

import com.mongodb.MongoClient;
import com.mongodb.client.*;
import org.bson.Document;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
class MongoDB {
    private MongoDatabase baseDeDatos;
    private MongoCollection coleccion;

    public MongoDB(){
        this.conectar("inventario","producto");
    }

    public MongoDB(String coleccion) {
        this.conectar("inventario",coleccion);
    }

    public void conectar(String baseDeDatos,String coleccion){
        this.conectarABaseDeDatos(baseDeDatos);
        this.conectarAColeccion(coleccion);
    }

    public MongoDatabase getBaseDeDatos() {
        return baseDeDatos;
    }

    public void setBaseDeDatos(MongoDatabase baseDeDatos) {
        this.baseDeDatos = baseDeDatos;
    }

    public MongoCollection getColeccion() {
        return coleccion;
    }

    public void setColeccion(MongoCollection coleccion) {
        this.coleccion = coleccion;
    }

    public void conectarABaseDeDatos(String nombreBaseDeDatos){
        MongoClient mongo = new MongoClient("localhost",27017);
        this.baseDeDatos = mongo.getDatabase(nombreBaseDeDatos);
    }

    public void conectarAColeccion(String nombreDeColeccion){
        if (this.existeLaColeccion(nombreDeColeccion)){
            this.coleccion = baseDeDatos.getCollection(nombreDeColeccion);
        } else {
            baseDeDatos.createCollection(nombreDeColeccion);
            this.coleccion = baseDeDatos.getCollection(nombreDeColeccion);
        }
    }

    public boolean existeLaColeccion(String nombreDeColeccion){

        MongoIterable<String> nombresDeColecciones = baseDeDatos.listCollectionNames();
        boolean existe = false;

        for (String nombre : nombresDeColecciones) {
            if (nombre.equals(nombreDeColeccion)){
                existe = true;
            }
        }
        return existe;
    }


    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //METODOS NUEVOS
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////

    public void ingresarProductoInalambrico(HashMap<String,Object> producto){
        ProductoInalambrico productoInalambrico = new ProductoInalambrico();
        productoInalambrico.setNombre((String) producto.get("nombre"));
        productoInalambrico.setCategoria((String) producto.get("categoria"));
        productoInalambrico.setStock(Integer.parseInt((String) producto.get("stock")) );
        productoInalambrico.setStockMinimo(Integer.parseInt((String) producto.get("stockDeReposicion")) );
        productoInalambrico.setPrecioCompra(Double.parseDouble((String)producto.get("precioCompra")) );
        productoInalambrico.setPrecioVenta(Double.parseDouble((String) producto.get("precioVenta")) );
        productoInalambrico.setCategoria((String) producto.get("categoria"));
        productoInalambrico.setFrecuencia(Integer.parseInt((String) producto.get("frecuencia")) );
        productoInalambrico.setTiempoBateria(Integer.parseInt((String)producto.get("tiempoBateria") ) );
        productoInalambrico.setNombreProveedor((String) producto.get("nombreProveedor"));
        productoInalambrico.generarDescripcion();

        this.conectar("inventario","producto");

        Document nuevoDocumento = new Document();
        nuevoDocumento.append("nombre",productoInalambrico.getNombre());
        nuevoDocumento.append("descripcion",productoInalambrico.getDescripcion());
        nuevoDocumento.append("categoria",productoInalambrico.getCategoria());
        nuevoDocumento.append("stock",productoInalambrico.getStock());
        nuevoDocumento.append("stockReposicion",productoInalambrico.getStockMinimo());
        nuevoDocumento.append("precioCompra",productoInalambrico.getPrecioCompra());
        nuevoDocumento.append("precioVenta",productoInalambrico.getPrecioVenta());
        nuevoDocumento.append("nombreProveedor",productoInalambrico.getNombreProveedor());

        this.coleccion.insertOne(nuevoDocumento);
    }

    public void ingresarProductosConCables(HashMap<String,Object> producto){
        ProductoConCable productoConCable = new ProductoConCable();
        productoConCable.setNombre((String) producto.get("nombre"));
        productoConCable.setCategoria((String) producto.get("categoria"));
        productoConCable.setStock(Integer.parseInt((String) producto.get("stock")) );
        productoConCable.setStockMinimo(Integer.parseInt((String) producto.get("stockDeReposicion")) );
        productoConCable.setPrecioCompra(Double.parseDouble((String)producto.get("precioCompra")) );
        productoConCable.setPrecioVenta(Double.parseDouble((String) producto.get("precioVenta")) );
        productoConCable.setConector((String) producto.get("conector"));
        productoConCable.setCategoria((String) producto.get("categoria"));
        productoConCable.setLargoCable(Integer.parseInt((String)producto.get("largoCable") ) );
        productoConCable.setVelocidadDeRespuesta((String) producto.get("velocidadRespuesta"));

        this.conectar("inventario","producto");

        Document nuevoDocumento = new Document();
        nuevoDocumento.append("nombre",productoConCable.getNombre());
        nuevoDocumento.append("descripcion",productoConCable.getDescripcion());
        nuevoDocumento.append("categoria",productoConCable.getCategoria());
        nuevoDocumento.append("stock",productoConCable.getStock());
        nuevoDocumento.append("stockReposicion",productoConCable.getStockMinimo());
        nuevoDocumento.append("precioCompra",productoConCable.getPrecioCompra());
        nuevoDocumento.append("precioVenta",productoConCable.getPrecioVenta());
        nuevoDocumento.append("nombreProveedor",productoConCable.getNombreProveedor());

        this.coleccion.insertOne(nuevoDocumento);
    }

    public HashMap<String,Object> obtenerDatosProducto(){
        HashMap<String,Object> datos = new HashMap<>();
        ArrayList<HashMap<String,Object>> productos = new ArrayList<>();

        FindIterable resultado = coleccion.find();
        MongoCursor iterador = resultado.iterator();

        while (iterador.hasNext()) {
            Document documento = (Document) iterador.next();
            String nombre = documento.getString("nombre");
            String desc = documento.getString("descripcion");
            String categoria = documento.getString("categoria");
            /*
            double precioCompra = Double.parseDouble(documento.getString("precioCompra")) ;
            double precioVenta = Double.parseDouble(documento.getString("precioVenta"));
            int stock = Integer.parseInt(documento.getString("stock")) ;
            int stockMinimo = Integer.parseInt(documento.getString("stockReposicion")) ;*/

            double precioCompra = documento.getDouble("precioCompra");
            double precioVenta = documento.getDouble("precioVenta");
            int stock = documento.getInteger("stock");
            int stockMinimo = documento.getInteger("stockReposicion");
            String nombreProveedor = documento.getString("nombreProveedor");

            HashMap<String,Object> producto = new HashMap<>();

            producto.put("nombre",nombre);
            producto.put("descripcion",desc);
            producto.put("categoria",categoria);
            producto.put("precioCompra",precioCompra);
            producto.put("precioVenta",precioVenta);
            producto.put("stock",stock);
            producto.put("stockMinimo",stockMinimo);
            producto.put("nombreProveedor",nombreProveedor);

            productos.add(producto);

        }

        datos.put("productos",productos);
        return datos;
    }

    public HashMap<String,Object> obtenerDatosProveedores(){
        HashMap<String,Object> datos = new HashMap<>();
        ArrayList<Proveedor> proveedores = new ArrayList<>();

        FindIterable resultado = coleccion.find();
        MongoCursor iterador = resultado.iterator();

        while (iterador.hasNext()) {
            Document documento = (Document) iterador.next();
            Document ubicacion = (Document) documento.get("ubicacion");
            String nombre = documento.getString("nombre");
            int contacto = documento.getInteger("contacto");
            Ubicacion ubicacion1 = new Ubicacion(ubicacion.getString("pais"), ubicacion.getString("ciudad"),ubicacion.getString("direccion") );

            Proveedor proveedor = new Proveedor(nombre,ubicacion1,contacto);

            proveedores.add(proveedor);
        }

        datos.put("Proveedores: ",proveedores);
        return datos;
    }

    public HashMap<String,Object> obtenerProducto(String nombre) {
        HashMap<String,Object> datos = new HashMap<>();
        //Producto alumno = new Producto();
        /** aquí se deben tomar los valores del map para armar el json (opcional) **/
        String json = "{ nombre : { $eq : \"" + nombre + "\" } }";
        Document filtro = Document.parse(json);
        FindIterable resultado = coleccion.find(filtro);
        MongoCursor iterador = resultado.iterator();

        while (iterador.hasNext()){
            Document documento = (Document) iterador.next();
            //String nombre = documento.getString("nombre");
            datos.put("nombre",nombre);
            datos.put("descripcion",documento.getString("descripcion"));
            datos.put("categoria",documento.getString("categoria"));
            datos.put("precioCompra",documento.getDouble("precioCompra"));
            datos.put("precioVenta",documento.getDouble("precioVenta"));
            datos.put("stock",documento.getInteger("stock"));
            datos.put("stockMinimo",documento.getInteger("stockReposicion"));
            datos.put("nombreProveedor",documento.getString("nombreProveedor"));
        }

        return datos;
    }

    public void insertProducto(HashMap<String,Object> elementoAgregar){
        this.conectar("inventario","producto");
        Document nuevoDocumento = new Document();
        for (String campo : elementoAgregar.keySet()){
            if (campo == "stock" || campo == "stockDeReposicion"){
                nuevoDocumento.append(campo,"NumberInt(" + elementoAgregar.get(campo) + ")");
            }
            else{
                nuevoDocumento.append(campo,elementoAgregar.get(campo));
            }
        }
    }

    public void actualizarDocumento(String nombre,String campo,Object nuevoValor,String coleccion){
        this.conectar("inventario",coleccion);
        String json = "{ nombre : { $eq :'" + nombre +"' } }";
        Document filtro = Document.parse(json);
        System.out.println("Nuevo valor: " + nuevoValor);
        if(campo.equals("precioCompra") || campo.equals("precioVenta") || campo.equals("stock") || campo.equals("stockReposicion")){
            json = "{ $set: { " + campo + ":" + nuevoValor + " } }";
        }
        else{
            json = "{ $set: { " + campo + ":'" + nuevoValor + "'} }";
        }


        Document nuevosValores= Document.parse(json);
        this.coleccion.updateOne(filtro,nuevosValores);
    }

    public void eliminarDocumento(String nombre,String coleccion){
        this.conectar("inventario",coleccion);
        String json = "{ nombre: { $eq: " + "\"" + nombre + "\"" + "} }";
        System.out.println(nombre);
        System.out.println(json);
        Document filtro = Document.parse(json);
        this.coleccion.deleteOne(filtro);
    }

    public static void main(String[] args) {
        MongoDB mongo = new MongoDB("producto");
        mongo.obtenerDatosProducto();
    }
    /**
     * documentación de clase Document
     * http://mongodb.github.io/mongo-java-driver/3.6/javadoc/org/bson/Document.html
     */

}
