package com.example.demo;

public interface MetodosProducto {
    public String generarDescripcion();
}
